@REM ==========================================
@REM ��UCGameSDK��jar/swc�����ANE�ļ�
@REM ���ߣ�wangchuanju
@REM ���ڣ�2013-3-25
@REM ==========================================
@REM
@REM

@REM [PATH_TO_AIR_SDK]\bin\adt -package -target ane com.aneexample.AndroidDialog.ane .\extension.xml -swc .\AndroidDialogAPI.swc -platform Android-ARM -C .\Android-ARM .
@REM java -jar adt.jar -package -tsa none -storetype pkcs12 -keystore a.p12 -storepass 123 -target ane m.ane extension.xml  -swc myExtensionAs.swc -platform Android-ARM library.swf myExtensionJava.jar
@REM java -jar adt.jar -package -tsa none -storetype pkcs12 -keystore a.p12 -storepass 123 -target ane m.ane extension.xml  -swc myExtensionAs.swc -platform Android-ARM library.swf myExtensionJava.jar


@REM �� .swc ���Ƶ� ane ���Ŀ¼
SET SWC_FILE=UCGameSDK_ANE_AS.swc
SET SOURCE_SWC_PATH=..\UCGameSDK_ANE_AS\bin

copy /B /Y %SOURCE_SWC_PATH%\%SWC_FILE% .

@REM �� .swc ���ѹ�� library.swf 
SET ZIP_CMD="C:\Program Files\7-Zip\7z.exe"
%ZIP_CMD% e -y .\%SWC_FILE% library.swf

@REM ��� .ane
SET ANE_FILE=ucgamesdk.android.ane
SET JAR_FILE=UCGameSDKANEJava.jar

SET FLEX_ADT_CMD=java -jar "D:\programfiles\Adobe\Adobe Flash Builder 4.6\sdks\4.6.0\lib\adt.jar"

%FLEX_ADT_CMD% -package -tsa none -storetype pkcs12 -keystore signature.p12 -storepass 123456 -target ane %ANE_FILE% extension.xml -swc %SWC_FILE% -platform Android-ARM library.swf %JAR_FILE% 


@REM �� .ane ���Ƶ� demo �� libs Ŀ¼��
copy /B /Y .\%ANE_FILE% ..\UCGameSDK_ANE_Demo\libs



