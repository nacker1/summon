package cn.uc.gamesdk.ane;

import org.json.JSONObject;

import android.util.Log;
import cn.uc.gamesdk.UCCallbackListener;
//import cn.uc.gamesdk.UCCallbackListenerNullException;
import cn.uc.gamesdk.UCGameSDK;

import com.adobe.fre.FREContext;
import com.adobe.fre.FREFunction;
import com.adobe.fre.FREObject;

public class UCFUPointCharge implements FREFunction {
    private final static String TAG = "UCFUPointCharge";

    public FREObject call(FREContext context, FREObject[] args) {
        Log.d(TAG, "UCFUPointCharge calling...");
        try {
            UCGameSDK.defaultSDK().uPointCharge(context.getActivity(), args[0].getAsInt(), new Listener(context).uPointChargeListener);
        //} catch (UCCallbackListenerNullException e) {
        //    e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }


    private class Listener {
        private FREContext context;

        public Listener(FREContext context) {
            this.context = context;
        }

        public UCCallbackListener<String> uPointChargeListener = new UCCallbackListener<String>() {

            @Override
            public void callback(int code, String msg) {
                Log.d(TAG, "Received upoint charge event: code=" + code + ", msg=" + msg);

                try {
                    JSONObject jobj = new JSONObject();
                    jobj.put("callbackType", "UPointCharge");
                    jobj.put("code", code);
                    jobj.put("data", msg);
                    if (context != null) {
                        context.dispatchStatusEventAsync(jobj.toString(), "");
                    } else {
                        Log.d(TAG, "dispatchStatusEventAsync canceled: context is null");
                    }
                } catch (Throwable e) {
                    Log.e(TAG, e.getMessage(), e);
                }
            }
        };
    }

}
