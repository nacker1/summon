package cn.uc.gamesdk.ane;

import android.util.Log;
//import cn.uc.gamesdk.UCCallbackListenerNullException;
import cn.uc.gamesdk.UCGameSDK;

import com.adobe.fre.FREContext;
import com.adobe.fre.FREFunction;
import com.adobe.fre.FREObject;

public class UCFDestroyFloatButton implements FREFunction {
    private final static String TAG = "UCFDestroyFloatButton";

    public FREObject call(FREContext context, FREObject[] args) {
        Log.d(TAG, "UCFDestroyFloatButton calling...");
        try {
            UCGameSDK.defaultSDK().destoryFloatButton(context.getActivity());
        //} catch (UCCallbackListenerNullException e) {
        //    e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

}
