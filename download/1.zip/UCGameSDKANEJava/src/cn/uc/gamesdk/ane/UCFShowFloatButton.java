package cn.uc.gamesdk.ane;

import android.util.Log;
//import cn.uc.gamesdk.UCCallbackListenerNullException;
import cn.uc.gamesdk.UCGameSDK;

import com.adobe.fre.FREContext;
import com.adobe.fre.FREFunction;
import com.adobe.fre.FREObject;

public class UCFShowFloatButton implements FREFunction {
    private final static String TAG = "UCFShowFloatButton";

    public FREObject call(FREContext context, FREObject[] args) {
        Log.d(TAG, "UCFShowFloatButton calling...");
        try {
            UCGameSDK.defaultSDK().showFloatButton(context.getActivity(), (float) args[0].getAsDouble(), (float) args[1].getAsDouble(), args[2].getAsBool());
        //} catch (UCCallbackListenerNullException e) {
        //    e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

}
