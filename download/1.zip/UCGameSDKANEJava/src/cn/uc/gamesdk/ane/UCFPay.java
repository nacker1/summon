package cn.uc.gamesdk.ane;

import org.json.JSONObject;

import android.util.Log;
import cn.uc.gamesdk.UCCallbackListener;
//import cn.uc.gamesdk.UCCallbackListenerNullException;
import cn.uc.gamesdk.UCGameSDK;
import cn.uc.gamesdk.UCGameSDKStatusCode;
import cn.uc.gamesdk.info.OrderInfo;
import cn.uc.gamesdk.info.PaymentInfo;

import com.adobe.fre.FREContext;
import com.adobe.fre.FREFunction;
import com.adobe.fre.FREObject;

/**
 * 调用充值功能
 * 
 * @param allowContinuousPay
 *            是否允许连续充值
 * @param amount
 *            金额
 * @param serverId
 *            服务器ID
 * @param roleId
 *            用户角色ID
 * @param roleName
 *            用户角色名称
 * @param userGrade
 *            用户角色的当前等级
 * @param customInfo
 *            自定义信息
 */
public class UCFPay implements FREFunction {
    private final static String TAG = "UCFPay";

    public FREObject call(FREContext context, FREObject[] args) {
        Log.d(TAG, "UCFPay calling...");
        try {
            PaymentInfo payInfo = new PaymentInfo();
            payInfo.setAllowContinuousPay(args[0].getAsBool());
            payInfo.setAmount((float) args[1].getAsDouble());
            payInfo.setServerId(args[2].getAsInt());
            payInfo.setRoleId(args[3].getAsString());
            payInfo.setRoleName(args[4].getAsString());
            payInfo.setGrade(args[5].getAsString());
            payInfo.setCustomInfo(args[6].getAsString());
            // 加入支付回调地址
            payInfo.setNotifyUrl(args[7].getAsString());
            //加入自有交易号
            payInfo.setTransactionNumCP(args[8].getAsString());

            try {
                UCGameSDK.defaultSDK().pay(context.getActivity().getApplicationContext(), payInfo, 
                        new Listener(context).orderResultListener);
            //} catch (UCCallbackListenerNullException e) {
            //    e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


    private class Listener {
        private FREContext context;

        public Listener(FREContext context) {
            this.context = context;
        }

        public UCCallbackListener<OrderInfo> orderResultListener = new UCCallbackListener<OrderInfo>() {

            @Override
            public void callback(int code, OrderInfo orderInfo) {
                String text = null;

                switch (code) {
                case UCGameSDKStatusCode.SUCCESS:
                    if (orderInfo != null) {
                        String orderId = orderInfo.getOrderId();
                        float amount = orderInfo.getOrderAmount();
                        int payway = orderInfo.getPayWay();
                        String paywayName = orderInfo.getPayWayName();

                        text = "Order Result: OrderId=" + orderId + ", Amount=" + amount + ", PayWayId=" + payway + ", PayWayName=" + paywayName;
                        Log.d(TAG, text);
                        text = null;

                        //
                    } else {
                        Log.e(TAG, "Received empty order result");
                    }

                    break;
                case UCGameSDKStatusCode.NO_INIT:
                    text = "Paying failed: no init";
                    Log.e(TAG, text);
                    break;
                case UCGameSDKStatusCode.PAY_USER_EXIT:
                    text = "User exit the paying page, return to game page.";
                    Log.d(TAG, text);
                    break;
                default:
                    text = "Unknown paying result code: code=" + code;
                    Log.e(TAG, text);
                    break;

                }


                try {
                    JSONObject jobj = new JSONObject();
                    jobj.put("callbackType", "Pay");
                    jobj.put("code", code);

                    if (orderInfo == null) {
                        jobj.put("data", null);
                    } else {
                        JSONObject jdata = new JSONObject();
                        jdata.put("orderId", orderInfo.getOrderId());
                        jdata.put("orderAmount", orderInfo.getOrderAmount());
                        jdata.put("payWay", orderInfo.getPayWay());
                        jdata.put("payWayName", orderInfo.getPayWayName());

                        jobj.put("data", jdata);
                    }
                    if (context != null) {
                        context.dispatchStatusEventAsync(jobj.toString(), "");
                    } else {
                        Log.d(TAG, "dispatchStatusEventAsync canceled: context is null");
                    }
                } catch (Throwable e) {
                    Log.e(TAG, "", e);
                }

            }
        };
    }

}
