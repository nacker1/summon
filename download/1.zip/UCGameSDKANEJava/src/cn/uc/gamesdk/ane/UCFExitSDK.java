package cn.uc.gamesdk.ane;

import org.json.JSONObject;

import android.util.Log;
import cn.uc.gamesdk.UCCallbackListener;
//import cn.uc.gamesdk.UCCallbackListenerNullException;
import cn.uc.gamesdk.UCGameSDK;
import cn.uc.gamesdk.UCGameSDKStatusCode;

import com.adobe.fre.FREContext;
import com.adobe.fre.FREFunction;
import com.adobe.fre.FREObject;

public class UCFExitSDK implements FREFunction {
    private final static String TAG = "UCFExitSDK";

    public FREObject call(FREContext context, FREObject[] args) {
        Log.d(TAG, "UCFExitSDK calling...");
        try {
            UCGameSDK.defaultSDK().exitSDK(context.getActivity(), new Listener(context).exitListener);
        //} catch (UCCallbackListenerNullException e) {
        //    e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }
    
    private static class Listener {
        private FREContext context;

        public Listener(FREContext context) {
            this.context = context;
        }

        private UCCallbackListener<String> exitListener = new UCCallbackListener<String>() {
            public void callback(int code, String msg) {
                Log.d(TAG, "UCGameSDK exit result: code=" + code + ", msg=" + msg + "");
                switch (code) {
                //退出游戏
                case UCGameSDKStatusCode.SDK_EXIT:
                    break;
                //继续游戏
                case UCGameSDKStatusCode.SDK_EXIT_CONTINUE:
                    break;
                default:
                    break;
                }

                try {
                    JSONObject jobj = new JSONObject();
                    jobj.put("callbackType", "ExitSDK");
                    jobj.put("code", code);
                    jobj.put("data", msg);
                    if (context != null) {
                        Log.d(TAG, "dispatch exit result event to AIR context.");
                        context.dispatchStatusEventAsync(jobj.toString(), "");
                    } else {
                        Log.d(TAG, "dispatchStatusEventAsync canceled: context is null");
                    }
                } catch (Throwable e) {
                    Log.e(TAG, "", e);
                }
            }
        };
    }


}
