package cn.uc.gamesdk.ane;

import android.util.Log;
import cn.uc.gamesdk.UCGameSDK;
import cn.uc.gamesdk.UCLoginFaceType;

import com.adobe.fre.FREContext;
import com.adobe.fre.FREFunction;
import com.adobe.fre.FREObject;

/**
 * 设置登录界面风格：
 * USE_WIDGET - 简版登录界面
 * USE_STANDARD - 标准版登录界面
 */
public class UCFSetLoginUISwitch implements FREFunction {
    private final static String TAG = "UCFSetLoginUISwitch";

    /**
     * 游戏默认使用"简版"登录界面
     */
    public final static int UCLOGIN_FACETYPE_DEFAULT = 0;

    /**
     * 设置使用"简版"登录界面
     */
    public final static int UCLOGIN_FACETYPE_USE_WIDGET = 1;

    /**
     * 设置使用标准版登录界面
     */
    public final static int UCLOGIN_FACETYPE_USE_STANDARD = 2;


    public FREObject call(FREContext context, FREObject[] args) {
        Log.d(TAG, "UCFSetLoginUISwitch calling...");
        try {
            int facetype = args[0].getAsInt();
            UCLoginFaceType loginFaceType = UCLoginFaceType.DEFAULT;

            if (facetype == UCLOGIN_FACETYPE_USE_WIDGET)
                loginFaceType = UCLoginFaceType.USE_WIDGET;
            else if (facetype == UCLOGIN_FACETYPE_USE_WIDGET)
                loginFaceType = UCLoginFaceType.USE_STANDARD;

            UCGameSDK.defaultSDK().setLoginUISwitch(loginFaceType);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


}
