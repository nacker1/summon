## ==========================================
## 将UCGameSDK的jar/swc打包成ANE文件
## 作者：wangchuanju
## 日期：2013-3-25
## ==========================================

## [PATH_TO_AIR_SDK]\bin\adt -package -target ane com.aneexample.AndroidDialog.ane .\extension.xml -swc .\AndroidDialogAPI.swc -platform Android-ARM -C .\Android-ARM .
## java -jar adt.jar -package -tsa none -storetype pkcs12 -keystore a.p12 -storepass 123 -target ane m.ane extension.xml  -swc myExtensionAs.swc -platform Android-ARM library.swf myExtensionJava.jar
## java -jar adt.jar -package -tsa none -storetype pkcs12 -keystore a.p12 -storepass 123 -target ane m.ane extension.xml  -swc myExtensionAs.swc -platform Android-ARM library.swf myExtensionJava.jar


## 把 .swc 复制到 ane 打包目录
SWC_FILE=UCGameSDK_ANE_AS.swc
SOURCE_SWC_PATH=../UCGameSDK_ANE_AS/bin

cp $SOURCE_SWC_PATH/$SWC_FILE ./

## 从 .swc 里解压出 library.swf 
unzip ./$SWC_FILE 

## 打包 .ane
ANE_FILE=ucgamesdk.android.ane
JAR_FILE=UCGameSDKANEJava.jar

FLEX_ADT_CMD="../AIRSDK/bin/adt"

$FLEX_ADT_CMD -package -tsa none -storetype pkcs12 -keystore signature.p12 -storepass 123456 -target ane $ANE_FILE extension.xml -swc $SWC_FILE -platform Android-ARM library.swf $JAR_FILE 

## 把 .ane 复制到 demo 的 libs 目录中
cp ./$ANE_FILE ../UCGameSDK_ANE_Demo/libs


